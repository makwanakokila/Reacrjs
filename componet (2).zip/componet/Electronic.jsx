import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Electronic = () => {
  const [product, setProduct] = useState([]); // Original data
  const [filterProduct, setFilterProduct] = useState([]); // Displayed data
  const [query, setQuery] = useState(""); // Search query
  const [sortOrder, setSortOrder] = useState("default"); // Sort order

  useEffect(() => {
    fetch("https://fakestoreapi.com/products/category/jewelery")
      .then((res) => res.json())
      .then((data) => {
        setProduct(data); // Store fetched data
        setFilterProduct(data); // Initialize displayed data
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const handleSearch = (e) => {
    const searchValue = e.target.value.toLowerCase();
    setQuery(searchValue);

    // Filter the data based on the search query
    const filteredData = product.filter((item) =>
      item.title.toLowerCase().includes(searchValue)
    );

    // Apply sorting to the filtered data
    if (sortOrder === "asc") {
      filteredData.sort((a, b) => a.price - b.price);
    } else if (sortOrder === "desc") {
      filteredData.sort((a, b) => b.price - a.price);
    }

    setFilterProduct(filteredData); // Update displayed data
  };

  const handleSort = (order) => {
    setSortOrder(order);

    // Sort the displayed data
    const sortedData = [...filterProduct];
    if (order === "asc") {
      sortedData.sort((a, b) => a.price - b.price);
    } else if (order === "desc") {
      sortedData.sort((a, b) => b.price - a.price);
    } else {
      sortedData = [...product]; 
      if (query) {
        sortedData = sortedData.filter((item) =>
          item.title.toLowerCase().includes(query)
        );
      }
    }

    setFilterProduct(sortedData); 
  };

  return (
    <div>
      <h1>Jewelry</h1>

      <input
        type="text"
        placeholder="Search by title..."
        value={query}
        onChange={handleSearch}
        style={{
          padding: "10px",
          width: "300px",
          borderRadius: "5px",
          border: "1px solid #ddd",
          marginRight: "10px",
        }}
      />

      <select
        id="sort"
        value={sortOrder}
        onChange={(e) => handleSort(e.target.value)}
        style={{
          padding: "5px 10px",
          fontSize: "16px",
          borderRadius: "5px",
          border: "1px solid #ddd",
        }}
      >
        <option value="default">Default</option>
        <option value="asc">Low to High</option>
        <option value="desc">High to Low</option>
      </select>

      <ul>
        {filterProduct.map((el) => (
          <li key={el.id} style={{ marginBottom: "20px", listStyleType: "none" }}>
            <Link to={`/productDetail/${el.id}`}>{el.title}</Link>
            <h4>Price: ${el.price}</h4>
            <h5>Category: {el.category}</h5>
          
            <br />
            
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Electronic;