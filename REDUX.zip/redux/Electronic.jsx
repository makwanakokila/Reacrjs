import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchElectronicProducts, setElectronics } from '../redux/ElecAction';

const Electronic = () => {
    const dispatch = useDispatch();
    const data = useSelector((state) => state.Elec); // Access the correct state

    // useEffect(() => {
    //     fetch("https://fakestoreapi.com/products/category/jewelery")
    //         .then((res) => res.json())
    //         .then((data) => {
    //             dispatch(setElectronics(data)); 
    //         })
    //         .catch((error) => {
    //             console.error("Error fetching data:", error);
    //         });
    // }, [dispatch]);

    useEffect(()=>{
        dispatch(fetchElectronicProducts());
    },[dispatch]);

    return (
        <div>
            <h1>Electronic</h1>
            <ul>
                {data.map((item, index) => (
                    <li key={index}>{item.title}</li> // Use item.title and add a key
                ))}
            </ul>
        </div>
    );
}

export default Electronic;