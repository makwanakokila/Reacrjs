import { combineReducers } from "redux";
import ElecReduser from "./ElecReduser";
import { counterReducer } from "./CounterReduser";
import { myReducer } from "./Reduser";
const rootReducer = combineReducers({
  Elec: ElecReduser,
  Counter: counterReducer,
  todo:myReducer ,
});

export default rootReducer;
