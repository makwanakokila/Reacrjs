import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { increment, reset, start, stop } from './CounterAction';

export default function Counter() {
  const dispatch = useDispatch();
  
  // Ensure you access 'Counter' state correctly
  const value = useSelector((state) => state.Counter.value);
  const isRunning = useSelector((state) => state.Counter.isRunning);

  useEffect(() => {
    let interval;
    if (isRunning) {
      interval = setInterval(() => {
        dispatch(increment());  // Dispatch increment every second
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);  // Cleanup interval on component unmount
  }, [isRunning, dispatch]);

  return (
    <div>
      <h1>Counter: {value}</h1>
      <button onClick={() => dispatch(start())} disabled={isRunning}>
        Start
      </button>
      <button onClick={() => dispatch(stop())} disabled={!isRunning}>
        Stop
      </button>
      <button onClick={() => dispatch(reset())}>Reset</button>
    </div>
  );
}
