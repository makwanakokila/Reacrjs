const arr = [];

export const myReducer = (state = arr, action) => {
    if (action.type === "add") {
        return [...state, action.payload];
    } else if (action.type === "delete") {
        return state.filter((_, index) => index !== action.payload); 
    } else if (action.type === "update") {
        return state.map((item, index) =>
            index === action.payload.index ? action.payload.newValue : item
        ); 
    } else {
        return state;
    }
};


                            