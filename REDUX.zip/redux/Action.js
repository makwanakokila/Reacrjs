export const addAction = (payload) => ({
    type: "add",
    payload,
});

export const deleteAction = (index) => ({
    type: "delete",
    payload: index,
});

export const updateAction = (index, newValue) => ({
    type: "update",
    payload: { index, newValue },
});


