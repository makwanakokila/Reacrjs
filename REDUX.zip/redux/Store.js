import {applyMiddleware, legacy_createStore as createStore } from "redux";
import rootReducer from "./RootReduser";
import { thunk } from "redux-thunk";

export const myStore=createStore(rootReducer,applyMiddleware(thunk))

