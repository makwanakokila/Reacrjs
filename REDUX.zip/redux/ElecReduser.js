const initialState = []; 

const ElecReducer = (state = initialState, action) => {
    switch (action.type) {
        case "SET_ELECTRONICS":
            return action.payload; 
        default:
            return state; 
    }
}

export default ElecReducer;