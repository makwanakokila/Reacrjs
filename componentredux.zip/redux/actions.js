import axios from 'axios';

export const ADD_STUDENT = 'ADD_STUDENT';
export const REMOVE_STUDENT = 'REMOVE_STUDENT';
export const UPDATE_STUDENT = 'UPDATE_STUDENT';
export const FETCH_STUDENTS_REQUEST = 'FETCH_STUDENTS_REQUEST';
export const FETCH_STUDENTS_SUCCESS = 'FETCH_STUDENTS_SUCCESS';
export const FETCH_STUDENTS_FAILURE = 'FETCH_STUDENTS_FAILURE';

export const addStudent = (student) => ({
  type: ADD_STUDENT,
  payload: student,
});

export const removeStudent = (studentId) => {
  return async (dispatch) => {
    try {
      await axios.delete(`http://localhost:3001/students/${studentId}`);
      dispatch({ type: REMOVE_STUDENT, payload: studentId });
    } catch (error) {
      console.error('Error removing student:', error);
    }
  };
};

export const updateStudent = (student) => {
  return async (dispatch) => {
    try {
      const response = await axios.put(`http://localhost:3001/students/${student.id}`, student);
      dispatch({ type: UPDATE_STUDENT, payload: response.data });
    } catch (error) {
      console.error('Error updating student:', error);
    }
  };
};

export const fetchStudents = () => {
  return async (dispatch) => {
    dispatch({ type: FETCH_STUDENTS_REQUEST });
    try {
      const response = await axios.get('http://localhost:3001/students');
      dispatch({ type: FETCH_STUDENTS_SUCCESS, payload: response.data });
    } catch (error) {
      dispatch({ type: FETCH_STUDENTS_FAILURE, payload: error.message });
    }
  };
};
