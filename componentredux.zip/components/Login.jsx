import React, { useState, useEffect } from "react";
import { getAuth, createUserWithEmailAndPassword, signOut, onAuthStateChanged } from "firebase/auth";
import { app } from "../Firebase"; 

const auth = getAuth(app);

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [user, setUser] = useState(null); 

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });
    return () => unsubscribe(); 
  }, []);

  const handleSignUp = () => {
    setError("");
    setSuccessMessage("");

    if (!email || !password) {
      setError("Please fill out all fields.");
      return;
    }

    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        setSuccessMessage("Account created successfully!");
        setEmail("");
        setPassword("");
      })
      .catch((error) => {
        setError(error.message);
      });
  };

  const handleLogout = () => {
    signOut(auth)
      .then(() => {
        setSuccessMessage("Logged out successfully!");
      })
      .catch((error) => {
        setError(error.message);
      });
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Student App</h1>

      {user ? (
        <div>
          <p>Welcome, {user.email}!</p>
          <button className="Logout-button"
            onClick={handleLogout} >
            Logout
          </button>
        </div>
      ) : (
        <div>
          <h2>Sign Up</h2>
          <div style={{ marginBottom: "20px" }}>
            <input className="input-password"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <br />
            <input className="input-password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}/>
          </div>
          <button className="sign-button"
            onClick={handleSignUp}
          >
            Sign Up
          </button>
        </div>
      )}

      {successMessage && <p style={{ color: "green", marginTop: "20px" }}>{successMessage}</p>}
    </div>
  );
};

export default Login;
