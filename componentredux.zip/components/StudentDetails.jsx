import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchStudents, removeStudent, updateStudent } from '../redux/actions';
import './StudentDetails.css'
const StudentDetails = () => {
  const dispatch = useDispatch();
  const { students, loading, error } = useSelector((state) => state);
  const [editingStudent, setEditingStudent] = useState(null);
  const [updatedName, setUpdatedName] = useState('');
  const [updatedRollNo, setUpdatedRollNo] = useState('');
  const [updatedClass, setUpdatedClass] = useState('');

  useEffect(() => {
    dispatch(fetchStudents());
  }, [dispatch]);

  const handleRemoveStudent = (id) => {
    dispatch(removeStudent(id));
  };

  const handleUpdateStudent = (student) => {
    setEditingStudent(student);
    setUpdatedName(student.name);
    setUpdatedRollNo(student.rollNo);
    setUpdatedClass(student.class);
  };

  const handleSaveUpdate = () => {
    const updatedStudent = {
      id: editingStudent.id,
      name: updatedName, // Update name
      rollNo: updatedRollNo,
      class: updatedClass,
    };
    dispatch(updateStudent(updatedStudent));
    setEditingStudent(null);
  };

  if (loading) return <p>Loading...</p>;

  return (
    <div className='Detail-room'>
      <h1>Student List</h1>
      {error && <p>{error}</p>}

      {/* Update Form Above the List */}
      {editingStudent && (
        <div>
          <h2>Edit Student</h2>
          <input
            type="text"
            placeholder="Updated Name"
            value={updatedName}
            onChange={(e) => setUpdatedName(e.target.value)}
          />
          <input
            type="text"
            placeholder="Updated Roll No"
            value={updatedRollNo}
            onChange={(e) => setUpdatedRollNo(e.target.value)}
          />
          <input
            type="text"
            placeholder="Updated Class"
            value={updatedClass}
            onChange={(e) => setUpdatedClass(e.target.value)}
          />
          <button onClick={handleSaveUpdate}>Save Changes</button>
        </div>
      )}

      {/* Student List */}
      <ul>
        {students.map((student) => (
          <li key={student.id}>
            <p>Name: {student.name}</p>
            <p>Roll No: {student.rollNo}</p>
            <p>Class: {student.class}</p>
            <div className="buttton-div">
            <button onClick={() => handleRemoveStudent(student.id)}>Remove</button>
            <button onClick={() => handleUpdateStudent(student)}>Edit</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default StudentDetails;
