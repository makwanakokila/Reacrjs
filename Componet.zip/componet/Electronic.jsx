import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

const Electronic = () => {
    const [state, setState] = useState([]);

    useEffect(() => {
        fetch('https://fakestoreapi.com/products/category/jewelery')
            .then((res) => res.json())
            .then((data) => {
                console.log(data);
                setState(data);
            })
            .catch((error) => {
                console.error("Error fetching data:", error);
            });
    }, []);

    return (
        <div>
            <h1>Jewelry</h1>
            <ul>
                {state.map((el) => (
                    <li key={el.id}>
                        <Link to={`/productDetail/${el.id}`}>{el.title}</Link>
                    </li>
                ))}
            </ul>

        </div>
    );
}

export default Electronic;
