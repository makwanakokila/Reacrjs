import React, {useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const DataFetch = () => {
    const [data, setData] = useState([]);

    useEffect(() => {
        fetch("http://localhost:3000/data")
            .then((res) => res.json())
            .then((data) => {
                setData(data);
            });
    }, []); // Dependency array
    
    return (
        <div>
            <h1>Data Fetch</h1>
            {/* <button>price wise shorting</button> */}
             {
            data.map((el,i)=>{
                return <>
                <Link to={`/product/${el.category}`}>{el.name}</Link>
                <img src={el.img}/>
                <p>{el.price}</p>
                </>
            })
        }
        </div>
    );
}

export default DataFetch;
