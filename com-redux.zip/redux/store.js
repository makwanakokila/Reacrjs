import { legacy_createStore as createStore, applyMiddleware } from 'redux';
import {thunk} from 'redux-thunk';
import studentsReducer from './reducers';

const store = createStore(studentsReducer, applyMiddleware(thunk));

export default store;
