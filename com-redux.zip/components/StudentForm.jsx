import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addStudent } from '../redux/actions';
import axios from 'axios';
import './StudentForm.css'
const StudentForm = () => {
  const dispatch = useDispatch();

  const [studentEmail, setStudentEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rollNo, setRollNo] = useState('');
  const [name, setName] = useState('');
  const [studentClass, setStudentClass] = useState('');

  const handleAddStudent = async () => {
    if (!studentEmail || !password || !rollNo || !studentClass || !name) {
      alert('Please fill all fields!');
      return;
    }

    const newStudent = {
      email: studentEmail,
      password,
      rollNo,
      name,
      class: studentClass,
    };

    try {
      const response = await axios.post('http://localhost:3001/students', newStudent);
      dispatch(addStudent(response.data));
      alert('Student added successfully!');

      setStudentEmail('');
      setPassword('');
      setRollNo('');
      setName('');
      setStudentClass('');
    } catch (error) {
      console.error('Error adding student:', error);
      alert('Failed to add student. Please try again.');
    }
  };

  return (
    <div className='form'>
      <h1>Student Form</h1>
      <input
        type="text"
        placeholder="Enter Student Name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <input
        type="email"
        placeholder="Enter Student Email"
        value={studentEmail}
        onChange={(e) => setStudentEmail(e.target.value)}
      />
      <input
        type="password"
        placeholder="Enter Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <input
        type="text"
        placeholder="Enter Roll No"
        value={rollNo}
        onChange={(e) => setRollNo(e.target.value)}
      />
      <input
        type="text"
        placeholder="Enter Class"
        value={studentClass}
        onChange={(e) => setStudentClass(e.target.value)}
      />
      <button onClick={handleAddStudent}>Add Student</button>
    </div>
  );
};

export default StudentForm;
