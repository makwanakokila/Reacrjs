import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchStudents } from '../redux/actions';
import './StudentList.css'
const StudentList = () => {
  const dispatch = useDispatch();
  const { students, loading, error } = useSelector((state) => state); 

  const [searchTerm, setSearchTerm] = useState('');
  const [sortedStudents, setSortedStudents] = useState([]);
  const [sortBy, setSortBy] = useState('rollNo'); // default sort by rollNo

  useEffect(() => {
    dispatch(fetchStudents());
  }, [dispatch]);

  useEffect(() => {
    // Sorting students by the selected criteria
    const sorted = [...students].sort((a, b) => {
      if (sortBy === 'rollNo') {
        return a.rollNo - b.rollNo; // Sort by rollNo
      }
      return a.class.localeCompare(b.class); // Sort by class (alphabetically)
    });
    setSortedStudents(sorted);
  }, [students, sortBy]);

  const handleSearch = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleSortChange = (e) => {
    setSortBy(e.target.value);
  };

  const filteredStudents = sortedStudents.filter((student) =>
    student.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return <p>Loading...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div>
      <div className='stuent_lits'>
      <h1>Student List</h1>
      
     <div className='serch-div'>
       {/* Search Input */}
       <input
        type="text"
        placeholder="Search by Name"
        value={searchTerm}
        onChange={handleSearch}
      />

      {/* Sort Dropdown */}
      <select onChange={handleSortChange} value={sortBy}>
        <option value="rollNo">Sort by Roll No</option>
      </select>

     </div>
      {/* Display Students */}
      <ul>
        {filteredStudents.map((student) => (
          <li key={student.id}>
            <p>Name: {student.name}</p>
            <p>Roll No: {student.rollNo}</p>
            <p>Class: {student.class}</p>
          </li>
        ))}
      </ul>
      </div>
    </div>
  );
};

export default StudentList;
