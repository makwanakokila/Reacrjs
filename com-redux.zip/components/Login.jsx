import React, { useState, useEffect } from "react";
import {
  getAuth,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  updateProfile,
  signInWithPopup,
  GoogleAuthProvider,
} from "firebase/auth";
import { app } from "../Firebase"; // Assuming Firebase is configured here

const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        onLogin();
      }
    });
    return () => unsubscribe();
  }, [onLogin]);

  const handleSignUp = () => {
    setError("");
    setSuccessMessage("");

    if (!email || !password) {
      setError("Please fill out all fields.");
      return;
    }

    createUserWithEmailAndPassword(auth, email, password)
      .then((userCredential) => {
        const currentUser = userCredential.user;

        // Update the display name
        updateProfile(currentUser, {
          displayName: email.split("@")[0], // Set the display name as email's first part
        })
          .then(() => {
            setSuccessMessage("Account created successfully!");
            setEmail("");
            setPassword("");
          })
          .catch((updateError) => {
            setError(updateError.message);
          });
      })
      .catch((error) => {
        setError(error.message);
      });
  };

  const handleGoogleSignIn = () => {
    setError("");
    setSuccessMessage("");

    signInWithPopup(auth, googleProvider)
      .then((result) => {
        const currentUser = result.user;
        setSuccessMessage(`Welcome, ${currentUser.displayName || currentUser.email}!`);
      })
      .catch((error) => {
        setError(error.message);
      });
  };

  const handleLogout = () => {
    signOut(auth)
      .then(() => {
        setSuccessMessage("Logged out successfully!");
      })
      .catch((error) => {
        setError(error.message);
      });
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>
        {user
          ? `Let’s Get Started, ${user.displayName || user.email.split("@")[0]}!`
          : "Welcome to the Student App!"}
      </h1>

      {user ? (
        <div>
          <p>Welcome, {user.email}!</p>
          <button className="Logout-button" onClick={handleLogout}>
            Logout
          </button>
        </div>
      ) : (
        <div>
          <h2>Sign Up</h2>
          <div style={{ marginBottom: "20px" }}>
            <input
              className="input-password"
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <br />
            <input
              className="input-password"
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button className="sign-button" onClick={handleSignUp}>
            Sign Up
          </button>
          <div style={{ marginTop: "20px" }}>
            <h3>Or</h3>
            <button
              className="google-signin-button"
              style={{
                backgroundColor: "#4285F4",
                color: "white",
                border: "none",
                padding: "10px 20px",
                borderRadius: "5px",
                cursor: "pointer",
              }}
              onClick={handleGoogleSignIn}
            >
              Continue with Google
            </button>
          </div>
        </div>
      )}

      {successMessage && <p style={{ color: "green", marginTop: "20px" }}>{successMessage}</p>}
    </div>
  );
};

export default Login;
